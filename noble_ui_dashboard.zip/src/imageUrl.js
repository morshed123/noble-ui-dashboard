// global.img_url = 'http://greatpharma.org/pos_server/public';
global.img_url = 'http://localhost/mhp-pos/pos_server/public';